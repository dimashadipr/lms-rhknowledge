<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2020081513.10; // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2017111300; // Requires this Moodle version.
$plugin->component = 'block_cocoon_course_grid_8'; // Full name of the plugin (used for diagnostics).
