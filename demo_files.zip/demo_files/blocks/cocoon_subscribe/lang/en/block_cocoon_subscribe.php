<?php
$string['pluginname'] = '[Cocoon] Subscribe';
$string['cocoon_subscribe'] = '[Cocoon] Subscribe';
$string['cocoon_subscribe:addinstance'] = 'Add a new Gallery block';
$string['cocoon_subscribe:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_lectures'] = 'Lectures';
$string['config_quizzes'] = 'Quizzes';
$string['config_duration'] = 'Duration';
$string['config_skill_level'] = 'Skill level';
$string['config_language'] = 'Language';
$string['config_assessments'] = 'Assessments';
