<?php

$string['configtitle'] = 'Block title';
$string['cocoon_tstmnls_2:addinstance'] = 'Add a new [Cocoon] Testimonials slider 2 block';
$string['cocoon_tstmnls_2:myaddinstance'] = 'Add a new [Cocoon] Testimonials slider 2 block to Dashboard';
$string['pluginname'] = '[Cocoon] Testimonials slider 2';
