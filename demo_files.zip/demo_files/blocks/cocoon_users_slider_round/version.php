<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'block_cocoon_users_slider_round';
$plugin->version = 2021032216.13;
$plugin->requires = 2017051500;
