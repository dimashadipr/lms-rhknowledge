<?php
$string['configtitle'] = 'Block title';
$string['cocoon_slider_6:addinstance'] = 'Add a new [Cocoon] Slider style 6 block';
$string['cocoon_slider_6:myaddinstance'] = 'Add a new [Cocoon] Slider style 6 block to Dashboard';
$string['pluginname'] = '[Cocoon] Slider style 6';
