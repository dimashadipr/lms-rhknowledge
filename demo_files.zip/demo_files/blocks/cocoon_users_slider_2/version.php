<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'block_cocoon_users_slider_2';
$plugin->version = 2020111617.49;
$plugin->requires = 2017051500;
