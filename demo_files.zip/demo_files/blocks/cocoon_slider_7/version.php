<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2021031612.46;
$plugin->requires  = 2017051504;
$plugin->component = 'block_cocoon_slider_7';
