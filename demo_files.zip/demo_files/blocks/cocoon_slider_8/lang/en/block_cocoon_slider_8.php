<?php
$string['configtitle'] = 'Block title';
$string['cocoon_slider_8:addinstance'] = 'Add a new [Cocoon] Slider style 8 block';
$string['cocoon_slider_8:myaddinstance'] = 'Add a new [Cocoon] Slider style 8 block to Dashboard';
$string['pluginname'] = '[Cocoon] Slider style 8';
