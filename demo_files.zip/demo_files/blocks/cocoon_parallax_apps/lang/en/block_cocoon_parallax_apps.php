<?php

$string['configtitle'] = 'Block title';
$string['cocoon_parallax_apps:addinstance'] = 'Add a new Custom slider block';
$string['cocoon_parallax_apps:myaddinstance'] = 'Add a new Custom slider block to Dashboard';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newcustomsliderblock'] = '(new Custom slider block)';
$string['pluginname'] = '[Cocoon] Parallax apps';

$string['slides_number'] = 'Number of slides';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_app_store_btn'] = 'App Store button';
$string['config_app_store_btn_title'] = 'Title';
$string['config_app_store_btn_subtitle'] = 'Subtitle';
$string['config_app_store_btn_link'] = 'Button link';
$string['config_play_store_btn'] = 'Play Store button';
$string['config_play_store_btn_title'] = 'Title';
$string['config_play_store_btn_subtitle'] = 'Subtitle';
$string['config_play_store_btn_link'] = 'Button link';
$string['config_image'] = 'Image';
