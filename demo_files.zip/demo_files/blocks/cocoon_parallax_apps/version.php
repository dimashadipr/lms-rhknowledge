<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2020081513.10;
$plugin->requires  = 2017051504;
$plugin->component = 'block_cocoon_parallax_apps';
